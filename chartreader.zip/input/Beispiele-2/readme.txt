- attached you find the additional charts 
  > they are slightly different from the "Beispiel" chart (linux vs windows fonts)
  > please use only the new charts
- x-axis: both chart versions have the same time interval: from 2018-01-01T23:00:00 to 2021-02-01T06:00:00
- y-axis: additionally, ignore charts with y-values below 1 and above 100,000,000
  > ignore e.g. the following charts in "Run 22":
    + 00.0-15.0-02.0-20000.0-10.0-20.0-00.0-02.0-10.0-NONE
    + 00.0-65.0-02.0-20000.0-45.0-20.0-00.0-14.0-20.0-NONE
    + 00.0-45.0-23.0-20000.0-24.0-27.0-00.0-08.0-40.0-NONE
	