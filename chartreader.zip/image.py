from PIL import Image

img = Image.open("chart.png")
